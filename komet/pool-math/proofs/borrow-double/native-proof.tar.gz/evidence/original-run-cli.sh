#!/bin/bash
set -eu
case "${1-}" in test_borrow_double) ;; *) exit 2 ;; esac
case "${2-}" in positive-cli) ;; *) exit 2 ;; esac
task_candidate=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$task_candidate/../../../../.."
task_trial="$task_candidate/$2"
test ! -e "$task_trial"
mkdir "$task_trial"
cp "$task_candidate/runtime.json" "$task_trial/runtime.json"
(cd "$task_candidate/../positive-cli" && /usr/bin/shasum -a 256 -c saved-proof.sha256 > "$task_trial/source-proof-check-before.log")
cp -R "$task_candidate/../positive-cli/proof" "$task_trial/proof"
task_source=$(CDPATH= cd -- "$task_candidate/../positive-cli" && pwd)
while read -r task_hash task_path; do
  case "$task_path" in "$task_source/proof/"*) ;; *) exit 2 ;; esac
  task_relative=${task_path#"$task_source/proof/"}
  printf '%s  %s\n' "$task_hash" "$task_trial/proof/$task_relative"
done < "$task_source/saved-proof.sha256" > "$task_trial/copied-proof.sha256"
/usr/bin/shasum -a 256 -c "$task_trial/copied-proof.sha256" > "$task_trial/copied-proof-check-before.log"
export KOMET_SMT_TRANSCRIPT="$task_trial/solver-transcript.smt2"
eval "$(/usr/bin/jq -r '.environment | to_entries[] | "export \(.key)=\(.value|@sh)"' "$task_trial/runtime.json")"
/usr/bin/jq '.environment + {KOMET_SMT_TRANSCRIPT:env.KOMET_SMT_TRANSCRIPT}'  "$task_trial/runtime.json" > "$task_trial/launch-environment.json"
/usr/bin/jq -r '.pins | to_entries[] | "\(.value)  \(.key)"' "$task_trial/runtime.json" > "$task_trial/runtime-pins.sha256"
/usr/bin/shasum -a 256 -c "$task_trial/runtime-pins.sha256" > "$task_trial/runtime-pins-before.log" 2> "$task_trial/runtime-pins-before-stderr.log"
/usr/bin/jq -n --arg cwd "$PWD" --arg id "$1" --arg dir "$task_trial/proof" '{cwd:$cwd, executable:"/nix/store/pnjdp53gn40j81n02qyyr77q4qf93j5n-komet-env/bin/komet", arguments:["prove","run","--always-allocate","--wasm","../wasm/pool_math_proof.wasm","--id",$id,"--extra-module","carry-word-20261007/continuation-01/double-word-20261007/double-cli.k:SIGNED-DISTRIBUTE-COMPLEMENT-NEGATIVE-PACK64-DOUBLE-RAY-SIGNED-DECODER-FLOOR-EQUALITY-LOW-WORD-SIGNED64-SIGN-FIXED64-XOR","--proof-dir",$dir], wall_cap_seconds:600, forced_stop_grace_seconds:15, continuation:true}' > "$task_trial/command.json"
task_started=$(date -u +%Y-%m-%dT%H:%M:%SZ)
task_epoch=$(date +%s)
set +e
/opt/homebrew/bin/timeout --signal=INT --kill-after=15s 600s \
  /nix/store/pnjdp53gn40j81n02qyyr77q4qf93j5n-komet-env/bin/komet prove run \
  --always-allocate --wasm ../wasm/pool_math_proof.wasm --id "$1" \
  --extra-module carry-word-20261007/continuation-01/double-word-20261007/double-cli.k:SIGNED-DISTRIBUTE-COMPLEMENT-NEGATIVE-PACK64-DOUBLE-RAY-SIGNED-DECODER-FLOOR-EQUALITY-LOW-WORD-SIGNED64-SIGN-FIXED64-XOR \
  --proof-dir "$task_trial/proof" > "$task_trial/stdout.log" 2> "$task_trial/stderr.log"
task_exit=$?
set -e
task_elapsed=$(( $(date +%s) - task_epoch ))
(cd "$task_candidate/../positive-cli" && /usr/bin/shasum -a 256 -c saved-proof.sha256 > "$task_trial/source-proof-check-after.log")
/usr/bin/jq -n --argjson code "$task_exit" --argjson wall "$task_elapsed" --arg started "$task_started" --arg id "$1" '{exit_code:$code,wall_seconds:$wall,wall_cap_seconds:600,forced_stop_grace_seconds:15,started_at:$started,program:"komet",id:$id,continuation:true}' > "$task_trial/process.json"
/usr/bin/shasum -a 256 -c "$task_trial/runtime-pins.sha256" > "$task_trial/runtime-pins-after.log" 2> "$task_trial/runtime-pins-after-stderr.log"
cat "$task_trial/process.json" "$task_trial/stdout.log"
exit "$task_exit"
