from __future__ import annotations

import json
import shutil
from dataclasses import dataclass
from functools import cached_property
from pathlib import Path
from tempfile import mkdtemp
from typing import TYPE_CHECKING

from hypothesis import Phase, given, settings, strategies
from pyk.cterm import CTerm, cterm_build_claim
from pyk.kast.inner import KApply, KSequence, KSort, KVariable
from pyk.kast.manip import Subst, split_config_from, top_down
from pyk.kast.outer import KClaim
from pyk.kast.prelude.ml import mlEqualsTrue
from pyk.kast.prelude.utils import token
from pyk.konvert import kast_to_kore, kore_to_kast
from pyk.kore.parser import KoreParser
from pyk.kore.prelude import str_dv
from pyk.kore.syntax import EVar, SortApp
from pyk.ktool.kfuzz import KFuzzHandler
from pyk.ktool.krun import KRunOutput
from pyk.proof import ProofStatus
from pyk.utils import run_process
from rich.console import Console
from rich.progress import BarColumn, MofNCompleteColumn, Progress, TextColumn, TimeElapsedColumn

from .kast.syntax import (
    SC_VOID,
    STEPS_TERMINATOR,
    account_id,
    call_tx,
    contract_id,
    deploy_contract,
    sc_bool,
    sc_bytes,
    set_account,
    set_exit_code,
    steps_of,
    upload_wasm,
)
from .proof import is_functional, run_claim, run_functional_claim
from .scval import SCType
from .utils import KSorobanError, concrete_definition, subst_on_program_cell
from .wasm import wasm2kast

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Mapping
    from typing import Any

    from hypothesis.strategies import SearchStrategy
    from pyk.kast.inner import KInner
    from pyk.kast.outer import KFlatModule
    from pyk.kore.syntax import Pattern
    from pyk.proof import APRProof, EqualityProof
    from pyk.utils import BugReport
    from rich.progress import TaskID

    from .scval import SCValue
    from .utils import SorobanDefinition


class Kasmer:
    """Reads soroban contracts, and runs tests for them."""

    definition: SorobanDefinition
    extra_module: KFlatModule | None
    trace_file: Path | None

    def __init__(
        self, definition: SorobanDefinition, extra_module: KFlatModule | None = None, trace_file: Path | None = None
    ) -> None:
        self.definition = definition
        self.extra_module = extra_module
        self.trace_file = trace_file

    def _which(self, cmd: str) -> Path:
        path_str = shutil.which(cmd)
        if path_str is None:
            raise RuntimeError(
                f"Couldn't find {cmd!r} executable. Please make sure {cmd!r} is installed and on your path."
            )
        return Path(path_str)

    @cached_property
    def concrete_definition(self) -> SorobanDefinition:
        if self.definition.is_concrete:
            return self.definition
        return concrete_definition()

    @cached_property
    def _stellar_bin(self) -> Path:
        return self._which('stellar')

    @cached_property
    def _cargo_bin(self) -> Path:
        return self._which('cargo')

    def config_vars(self) -> tuple[Mapping[str, str] | None, Mapping[str, str] | None]:
        if self.trace_file:
            cmap = {'TRACE': str_dv(str(self.trace_file)).text}
            pmap = {'TRACE': 'cat'}
            return cmap, pmap
        return None, None

    def contract_bindings(
        self, wasm_contract: Path, *, name_filter: Callable[[str], bool] | None = None
    ) -> list[ContractBinding]:
        """Read function bindings, optionally selecting names before parsing their types."""
        proc_res = run_process(
            [str(self._stellar_bin), 'contract', 'info', 'interface', '--output', 'json', '--wasm', str(wasm_contract)],
            check=True,
        )
        spec_entries = json.loads(proc_res.stdout)
        bindings = []
        for spec_entry in spec_entries:
            if 'function_v0' not in spec_entry:
                continue
            function_spec = spec_entry['function_v0']
            name = function_spec['name']
            if name_filter is not None and not name_filter(name):
                continue
            inputs = []
            for input_spec in function_spec['inputs']:
                input_type = input_spec['type'] if 'type' in input_spec else input_spec['type_']
                inputs.append(SCType.from_xdr_json(input_type))
            outputs = []
            for output_spec in function_spec['outputs']:
                outputs.append(SCType.from_xdr_json(output_spec))
            bindings.append(ContractBinding(name, tuple(inputs), tuple(outputs)))
        return bindings

    def contract_manifest(self, contract_path: Path) -> dict[str, Any]:
        """Get the cargo manifest for a given contract.

        Args:
            contract_path: The directory where the contract is located.

        Returns:
            A dictionary representing the json output of `cargo read-manifest` in that contract's directory.
        """
        proc_res = run_process([str(self._cargo_bin), 'read-manifest'], cwd=contract_path)
        return json.loads(proc_res.stdout)

    def build_soroban_contract(self, contract_path: Path, out_dir: Path | None = None) -> Path:
        """Build a soroban contract.

        Args:
            contract_path: The path to the soroban contract folder.
            out_dir: Where to save the compiled wasm. If this isn't passed, then a temporary location is created.

        Returns:
            The path to the compiled wasm contract.
        """
        contract_stem = self.contract_manifest(contract_path)['name'].replace('-', '_')
        contract_name = f'{contract_stem}.wasm'
        if out_dir is None:
            out_dir = Path(mkdtemp(f'komet_{str(contract_path.stem)}'))

        run_process([str(self._stellar_bin), 'contract', 'build', '--out-dir', str(out_dir)], cwd=contract_path)

        return out_dir / contract_name

    def kast_from_wasm(self, wasm: Path) -> KInner:
        """Get a kast term from a wasm program."""
        return wasm2kast(wasm.read_bytes())

    def contract_protocol(self, wasm: Path) -> int:
        """Read the uploaded code's protocol, which controls constructor behavior."""
        result = run_process(
            [str(self._stellar_bin), 'contract', 'info', 'env-meta', '--output', 'json', '--wasm', str(wasm)],
            check=True,
        )
        entries = json.loads(result.stdout)
        versions = [
            e['sc_env_meta_kind_interface_version'] for e in entries if 'sc_env_meta_kind_interface_version' in e
        ]
        if len(versions) != 1:
            raise ValueError('Contract must contain exactly one interface version')
        version = versions[0]
        protocol = version['protocol']
        if type(protocol) is not int or not 0 <= protocol <= 28 or version['pre_release'] != 0:
            raise ValueError(f'Unsupported contract interface version: {version}')
        return protocol

    def deploy_test(
        self,
        contract: KInner,
        child_contracts: tuple[KInner, ...],
        init: bool,
        protocol: int = 28,
        child_protocols: tuple[int, ...] | None = None,
    ) -> tuple[KInner, dict[str, KInner]]:
        """Takes a wasm soroban contract and its dependencies as kast terms and deploys them in a fresh configuration.

        Args:
            contract: The test contract to deploy, represented as a kast term.
            child_contracts: A tuple of child contracts required by the test contract.
            init: Whether to initialize the contract by calling its 'init' function after deployment.
            protocol: The test contract's interface protocol.
            child_protocols: Interface protocols corresponding to the child contracts; defaults to protocol 28.

        Returns:
            A configuration with the contract deployed.

        Raises:
            AssertionError if the deployment fails
        """

        def wasm_hash(i: int) -> bytes:
            return str(i).rjust(32, '_').encode()

        def call_init() -> tuple[KInner, ...]:
            hashes = tuple(wasm_hash(i) for i in range(len(child_contracts)))
            protocols = child_protocols if child_protocols is not None else (28,) * len(child_contracts)
            upload_wasms = tuple(
                upload_wasm(h, c, p) for h, c, p in zip(hashes, child_contracts, protocols, strict=True)
            )

            from_addr = account_id(b'test-account')
            to_addr = contract_id(b'test-contract')
            args = [sc_bytes(h) for h in hashes]
            init_tx = call_tx(from_addr, to_addr, 'init', args, SC_VOID)

            return upload_wasms + (init_tx,)

        # Set up the steps that will deploy the contract
        steps = steps_of(
            [
                set_exit_code(1),
                upload_wasm(b'test', contract, protocol),
                set_account(b'test-account', 9876543210),
                deploy_contract(b'test-account', b'test-contract', b'test'),
                *(call_init() if init else ()),
                set_exit_code(0),
            ]
        )

        cmap, pmap = self.config_vars()
        # Run the steps and grab the resulting config as a starting place to call transactions
        proc_res = self.concrete_definition.krun_with_kast(
            steps, sort=KSort('Steps'), output=KRunOutput.KORE, cmap=cmap, pmap=pmap
        )
        assert proc_res.returncode == 0

        kore_result = KoreParser(proc_res.stdout).pattern()
        kast_result = kore_to_kast(self.concrete_definition.kdefinition, kore_result)

        conf, subst = split_config_from(kast_result)

        return conf, subst

    def run_test(
        self,
        conf: KInner,
        subst: dict[str, KInner],
        binding: ContractBinding,
        max_examples: int,
        task: FuzzTask,
    ) -> None:
        """Given a configuration with a deployed test contract, fuzz over the tests for the supplied binding.

        Args:
            conf: The template configuration.
            subst: A substitution mapping such that 'Subst(subst).apply(conf)' gives the initial configuration with the
                   deployed contract.
            binding: The contract binding that specifies the test name and parameters.
            max_examples: The maximum number of fuzzing test cases to generate and execute.

        Raises:
            AssertionError if the test fails
        """

        from_acct = account_id(b'test-account')
        to_acct = contract_id(b'test-contract')
        name = binding.name
        result = sc_bool(True)

        def make_kvar(i: int) -> KInner:
            return KVariable(f'ARG_{i}', KSort('ScVal'))

        def make_evar(i: int) -> EVar:
            return EVar(f"VarARG'Unds'{i}", SortApp('SortScVal'))

        def make_steps(args: Iterable[KInner]) -> KInner:
            return steps_of([set_exit_code(1), call_tx(from_acct, to_acct, name, args, result), set_exit_code(0)])

        def scval_to_kore(val: SCValue) -> Pattern:
            return kast_to_kore(self.definition.kdefinition, val.to_kast(), KSort('ScVal'))

        vars = [make_kvar(i) for i in range(len(binding.inputs))]
        subst['PROGRAM_CELL'] = make_steps(vars)
        template_config = Subst(subst).apply(conf)
        template_config_kore = kast_to_kore(self.definition.kdefinition, template_config, KSort('GeneratedTopCell'))

        template_subst = {make_evar(i): b.strategy().map(scval_to_kore) for i, b in enumerate(binding.inputs)}

        handler = KometFuzzHandler(self.definition, task)

        # External semantic execution is bounded by examples, not Hypothesis's short CPU deadline.
        @given(strategies.fixed_dictionaries(template_subst))
        @settings(max_examples=max_examples, deadline=None, phases=(Phase.explicit, Phase.reuse, Phase.generate))
        def test_case(args: Mapping[EVar, Pattern]) -> None:
            handler.handle_test(args)
            pattern = subst_on_program_cell(template_config_kore, args)
            if not _run_test_case(self.definition, pattern):
                handler.handle_failure(args)

        test_case()

    def run_prove(
        self,
        conf: KInner,
        subst: dict[str, KInner],
        binding: ContractBinding,
        always_allocate: bool,
        proof_dir: Path | None = None,
        bug_report: BugReport | None = None,
    ) -> APRProof:
        """Given a configuration with a deployed test contract, prove the test case defined by the supplied binding.

        The target preserves successful termination and checks the Boolean assertion, while allowing the four
        transaction world-state cells to change. Post-state invariants belong in the test's Boolean assertion.

        Args:
            conf: The template configuration with configuration variables.
            subst: A substitution mapping such that `Subst(subst).apply(conf)` produces the initial configuration with
                   the deployed contract.
            binding: The contract binding specifying the test name and parameters.
            proof_dir: An optional directory to save the generated proof.
            bug_report: An optional object to log and collect details about the proof for debugging purposes.
        """
        from_acct = account_id(b'test-account')
        to_acct = contract_id(b'test-contract')
        name = binding.name
        result = sc_bool(True)

        def make_steps(*args: KInner) -> KInner:
            return steps_of([set_exit_code(1), call_tx(from_acct, to_acct, name, args, result), set_exit_code(0)])

        vars, ctrs = binding.symbolic_args()

        lhs_subst = subst.copy()
        lhs_subst['PROGRAM_CELL'] = make_steps(*vars)
        lhs_subst['ALWAYSALLOCATE_CELL'] = token(always_allocate)
        lhs = CTerm(Subst(lhs_subst).apply(conf), [mlEqualsTrue(c) for c in ctrs])

        rhs_subst = subst.copy()
        rhs_subst['PROGRAM_CELL'] = STEPS_TERMINATOR
        rhs_subst['EXITCODE_CELL'] = token(0)
        del rhs_subst['ALWAYSALLOCATE_CELL']
        # Match the pushWorldState/popWorldState boundary in configuration.md. Only RHS world state is fresh;
        # the concrete initial world, expected True result, and all terminal execution cells remain fixed.
        post_world_cells = {
            '<contracts>': ('POST_CONTRACTS_CELL', 'ContractCellMap'),
            '<accounts>': ('POST_ACCOUNTS_CELL', 'AccountCellMap'),
            '<contractData>': ('POST_CONTRACTDATA_CELL', 'Map'),
            '<contractCodes>': ('POST_CONTRACTCODES_CELL', 'ContractCodeCellMap'),
        }

        def fresh_post_world(cell: KInner) -> KInner:
            if type(cell) is KApply and cell.label.name in post_world_cells:
                name, sort = post_world_cells[cell.label.name]
                return cell.let(args=(KVariable(name, KSort(sort)),))
            return cell

        # split_config_from can expand singleton cell maps into their nested leaf cells. Project the actual
        # RHS tree so contracts/accounts/code are fresh even when no whole-cell substitution key exists.
        rhs = CTerm(top_down(fresh_post_world, Subst(rhs_subst).apply(conf)))

        claim, _ = cterm_build_claim(name, lhs, rhs)

        return run_claim(name, claim, self.extra_module, proof_dir, bug_report)

    def deploy_and_run(
        self, contract_wasm: Path, child_wasms: tuple[Path, ...], max_examples: int = 100, id: str | None = None
    ) -> None:
        """Run all of the tests in a soroban test contract.

        Args:
            contract_wasm: The path to the compiled wasm contract.
            child_wasms: A tuple of paths to the compiled wasm contracts required as dependencies by the test contract.
            max_examples: The maximum number of test inputs to generate for fuzzing.
            id: The specific test function name to run. If None, all tests are executed.

        Raises:
            AssertionError if any of the tests fail
        """
        test_bindings, has_init = self.read_bindings(contract_wasm, id)

        contract_kast = self.kast_from_wasm(contract_wasm)
        child_kasts = tuple(self.kast_from_wasm(c) for c in child_wasms)

        conf, subst = self.deploy_test(
            contract_kast,
            child_kasts,
            has_init,
            self.contract_protocol(contract_wasm),
            tuple(self.contract_protocol(c) for c in child_wasms),
        )

        failed: list[FuzzError] = []
        with FuzzProgress(test_bindings, max_examples) as progress:
            for task in progress.fuzz_tasks:
                try:
                    task.start()
                    self.run_test(conf, subst, task.binding, max_examples, task)
                    task.end()
                except FuzzError as e:
                    failed.append(e)

        if not failed:
            return

        console = Console(stderr=True)

        console.print(f'[bold red]{len(failed)}[/bold red] test/s failed:')

        for err in failed:
            pretty_args = ', '.join(self.definition.krun.pretty_print(a) for a in err.counterexample)
            console.print(f'  {err.test_name} ({pretty_args})')

        raise KSorobanError(failed)

    def deploy_and_prove(
        self,
        contract_wasm: Path,
        child_wasms: tuple[Path, ...],
        id: str | None = None,
        always_allocate: bool = False,
        proof_dir: Path | None = None,
        bug_report: BugReport | None = None,
    ) -> None:
        """Prove all of the tests in a soroban test contract.

        Args:
            contract_wasm: The path to the compiled wasm contract.
            child_wasms: A tuple of paths to the compiled wasm contracts required as dependencies by the test contract.
            id: The specific test function name to run. If None, all tests are executed.
            proof_dir: An optional location to save the proof.
            bug_report: An optional BugReport object to log and collect details about the proof for debugging.

        Raises:
            KSorobanError if a proof fails
        """
        test_bindings, has_init = self.read_bindings(contract_wasm, id)

        contract_kast = self.kast_from_wasm(contract_wasm)
        child_kasts = tuple(self.kast_from_wasm(c) for c in child_wasms)

        conf, subst = self.deploy_test(
            contract_kast,
            child_kasts,
            has_init,
            self.contract_protocol(contract_wasm),
            tuple(self.contract_protocol(c) for c in child_wasms),
        )

        with FuzzProgress(test_bindings, 1) as progress:
            for task in progress.fuzz_tasks:
                task.start()
                proof = self.run_prove(conf, subst, task.binding, always_allocate, proof_dir, bug_report)
                if proof.status == ProofStatus.PASSED:
                    task.advance()
                    task.end()
                else:
                    task.fail()
                    raise KSorobanError(proof.summary)

    def prove_raw(
        self,
        claim_file: Path,
        label: str | None = None,
        proof_dir: Path | None = None,
        bug_report: BugReport | None = None,
    ) -> None:

        modules = self.definition.kprove.parse_modules(claim_file).modules
        claims = [
            sent
            for module in modules
            for sent in module.sentences
            if isinstance(sent, KClaim) and (label is None or sent.label == label)
        ]
        if not claims:
            raise KSorobanError(f'No matching claims found in {claim_file} (label: {label!r}).')

        for claim in claims:
            print('Proving:', claim.label, 'at', claim.source)

            proof: EqualityProof | APRProof
            if is_functional(claim):
                proof = run_functional_claim(claim, proof_dir, bug_report)
                if proof.status != ProofStatus.PASSED:
                    raise KSorobanError(proof)
            else:
                proof = run_claim(claim.label, claim, self.extra_module, proof_dir, bug_report)
                if proof.status != ProofStatus.PASSED:
                    raise KSorobanError(proof.summary)

    def read_bindings(self, contract_wasm: Path, id: str | None) -> tuple[list[ContractBinding], bool]:
        print(f'Processing contract: {contract_wasm.stem}')

        bindings = self.contract_bindings(
            contract_wasm,
            name_filter=lambda name: name == 'init' or (name.startswith('test_') and (id is None or name == id)),
        )
        has_init = 'init' in (b.name for b in bindings)
        test_bindings = [b for b in bindings if b.name.startswith('test_') and (id is None or b.name == id)]

        if id is None:
            if not test_bindings:
                raise KeyError('No test functions found.')
            print(f'Discovered {len(test_bindings)} test functions:')
        elif not test_bindings:
            raise KeyError(f'Test function {id!r} not found.')
        else:
            print('Selected a single test function:')
        print()

        return test_bindings, has_init


@dataclass(frozen=True)
class ContractBinding:
    """Represents one of the function bindings for a soroban contract."""

    name: str
    inputs: tuple[SCType, ...]
    outputs: tuple[SCType, ...]

    @cached_property
    def strategy(self) -> SearchStrategy[tuple[KInner, ...]]:
        return strategies.tuples(*(arg.strategy().map(lambda x: x.to_kast()) for arg in self.inputs))

    def symbolic_args(self) -> tuple[tuple[KInner, ...], tuple[KInner, ...]]:
        args: tuple[KInner, ...] = ()
        constraints: tuple[KInner, ...] = ()
        for i, arg in enumerate(self.inputs):
            v, c = arg.as_var(f'ARG_{i}')
            args += (v,)
            constraints += c
        return args, constraints


class FuzzProgress(Progress):
    fuzz_tasks: list[FuzzTask]

    def __init__(self, bindings: Iterable[ContractBinding], max_examples: int):
        super().__init__(
            TextColumn('[progress.description]{task.description}'),
            BarColumn(),
            MofNCompleteColumn(),
            TimeElapsedColumn(),
            TextColumn('{task.fields[status]}'),
        )

        self.fuzz_tasks = []

        # Add all tests to the progress display before running them
        for binding in bindings:
            task_id = self.add_task(binding.name, total=max_examples, start=False, status='Waiting')
            self.fuzz_tasks.append(FuzzTask(binding, task_id, self))


class FuzzTask:
    binding: ContractBinding
    task_id: TaskID
    progress: FuzzProgress

    def __init__(self, binding: ContractBinding, task_id: TaskID, progress: FuzzProgress):
        self.binding = binding
        self.task_id = task_id
        self.progress = progress

    def start(self) -> None:
        self.progress.start_task(self.task_id)
        self.progress.update(self.task_id, status='[bold]Running')

    def end(self) -> None:
        self.progress.update(
            self.task_id, total=self.progress._tasks[self.task_id].completed, status='[bold green]Passed'
        )

    def advance(self) -> None:
        self.progress.advance(self.task_id)

    def fail(self) -> None:
        self.progress.update(self.task_id, status='[bold red]Failed')
        self.progress.stop_task(self.task_id)


def _run_test_case(definition: SorobanDefinition, pattern: Pattern) -> bool:
    # KRun owns the installed interpreter's CLI; pyk's raw fuzz command uses an older ABI.
    result = definition.krun.run_process(pattern, term=True)
    if result.returncode not in (0, 1):
        raise RuntimeError(f'Komet backend execution failed (exit {result.returncode}): {result.stderr}')
    try:
        terminal = kore_to_kast(definition.kdefinition, KoreParser(result.stdout).pattern())
        if not isinstance(terminal, KApply) or terminal.label.name != '<generatedTop>':
            raise ValueError('Expected a generated top configuration')
        _, cells = split_config_from(terminal)
        required = {
            'EXITCODE_CELL',
            'PROGRAM_CELL',
            'K_CELL',
            'INSTRS_CELL',
            'HOSTSTACK_CELL',
            'VALSTACK_CELL',
            'CALLSTACK_CELL',
        }
        if not required <= cells.keys():
            raise ValueError('Missing execution cells')
        exit_code = cells['EXITCODE_CELL']
    except Exception as error:
        raise RuntimeError(f'Komet backend returned no usable terminal configuration: {result.stderr}') from error
    if exit_code == token(1) and result.returncode == 1:
        k = cells['K_CELL']
        stack = cells['HOSTSTACK_CELL']
        if (
            isinstance(k, KSequence)
            and k.items
            and isinstance(k.items[0], KApply)
            and k.items[0].label.name == 'expectResult'
            and len(k.items[0].args) == 1
            and isinstance(stack, KApply)
            and stack.label.name == 'hostStackList'
            and len(stack.args) == 2
            and stack.args[1] == KApply('.List{"hostStackList"}')
            and (k.items[0].args[0], stack.args[0])
            in ((sc_bool(True), sc_bool(False)), (sc_bool(False), sc_bool(True)))
            and cells['INSTRS_CELL'] == KSequence()
            and cells['VALSTACK_CELL'] == KApply('.ValStack')
            and cells['CALLSTACK_CELL'] == KApply('.List')
        ):
            return False
        raise RuntimeError('Komet semantic execution stopped without a confirmed Boolean result mismatch')
    if exit_code != token(0) or result.returncode != 0:
        raise RuntimeError(f'Komet backend returned inconsistent exit codes: {result.returncode}, {exit_code}')
    if (
        cells.get('PROGRAM_CELL') != STEPS_TERMINATOR
        or cells.get('K_CELL') != KSequence()
        or cells.get('INSTRS_CELL') != KSequence()
        or cells.get('HOSTSTACK_CELL') != KApply('.List{"hostStackList"}')
        or cells.get('VALSTACK_CELL') != KApply('.ValStack')
        or cells.get('CALLSTACK_CELL') != KApply('.List')
    ):
        raise RuntimeError('Komet backend stopped before the test completed')
    return True


class KometFuzzHandler(KFuzzHandler):
    # Fuzz handler with progress tracking

    definition: SorobanDefinition
    task: FuzzTask
    failed: bool

    def __init__(self, definition: SorobanDefinition, task: FuzzTask):
        self.definition = definition
        self.task = task
        self.failed = False

    def handle_test(self, args: Mapping[EVar, Pattern]) -> None:
        # Hypothesis reruns failing examples to confirm the failure.
        # To avoid misleading progress updates, the progress bar is not advanced
        # when a test fails and Hypothesis reruns the same example.
        if not self.failed:
            self.task.advance()

    def handle_failure(self, args: Mapping[EVar, Pattern]) -> None:
        if not self.failed:
            self.failed = True
            self.task.fail()

        sorted_keys = sorted(args.keys(), key=lambda k: k.name)
        counterexample = tuple(self.definition.krun.kore_to_kast(args[k]) for k in sorted_keys)
        raise FuzzError(self.task.binding.name, counterexample)


class FuzzError(Exception):
    test_name: str
    counterexample: tuple[KInner, ...]

    def __init__(self, test_name: str, counterexample: tuple[KInner, ...]):
        super().__init__(test_name, counterexample)

        self.test_name = test_name
        self.counterexample = counterexample
